#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <mutex>
#include <atomic>
#include <thread>
#include <chrono>

// llama.cpp public headers (must match the cloned source tree)
#include "llama.h"
#include "ggml.h"

#define LOG_TAG "OmAiLlama"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)

// Global state protected by mutex
static std::mutex g_mutex;
static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;
static std::atomic<bool> g_cancel{false};
static std::atomic<bool> g_generating{false};

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------
static std::string jstring_to_string(JNIEnv* env, jstring jstr) {
    if (!jstr) return "";
    const char* chars = env->GetStringUTFChars(jstr, nullptr);
    std::string result(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(jstr, chars);
    return result;
}

static void free_context_locked() {
    if (g_ctx) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
}

static void free_model_locked() {
    free_context_locked();
    if (g_model) {
        llama_free_model(g_model);
        g_model = nullptr;
    }
}

// ------------------------------------------------------------------
// JNI: loadModel
// ------------------------------------------------------------------
extern "C"
JNIEXPORT jboolean JNICALL
Java_com_omai_app_ai_chat_LlamaNative_loadModel(
        JNIEnv* env,
        jobject /*thiz*/,
        jstring model_path,
        jint n_ctx,
        jint n_threads) {

    std::lock_guard<std::mutex> lock(g_mutex);
    free_model_locked();
    g_cancel = false;

    std::string path = jstring_to_string(env, model_path);
    if (path.empty()) {
        LOGE("loadModel: empty path");
        return JNI_FALSE;
    }

    LOGI("Loading GGUF model: %s  n_ctx=%d  n_threads=%d", path.c_str(), n_ctx, n_threads);

    llama_backend_init();

    llama_model_params model_params = llama_model_default_params();
    model_params.n_gpu_layers = 0; // CPU-only for maximum compatibility on Android

    g_model = llama_load_model_from_file(path.c_str(), model_params);
    if (!g_model) {
        LOGE("Failed to load model from %s", path.c_str());
        return JNI_FALSE;
    }

    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = n_ctx > 0 ? n_ctx : 2048;
    ctx_params.n_threads = n_threads > 0 ? n_threads : 4;
    ctx_params.n_threads_batch = ctx_params.n_threads;

    g_ctx = llama_new_context_with_model(g_model, ctx_params);
    if (!g_ctx) {
        LOGE("Failed to create context");
        free_model_locked();
        return JNI_FALSE;
    }

    LOGI("Model loaded successfully. vocab size = %d", llama_n_vocab(g_model));
    return JNI_TRUE;
}

// ------------------------------------------------------------------
// JNI: unloadModel
// ------------------------------------------------------------------
extern "C"
JNIEXPORT void JNICALL
Java_com_omai_app_ai_chat_LlamaNative_unloadModel(
        JNIEnv* /*env*/,
        jobject /*thiz*/) {

    std::lock_guard<std::mutex> lock(g_mutex);
    free_model_locked();
    llama_backend_free();
    LOGI("Model unloaded");
}

// ------------------------------------------------------------------
// JNI: isModelLoaded
// ------------------------------------------------------------------
extern "C"
JNIEXPORT jboolean JNICALL
Java_com_omai_app_ai_chat_LlamaNative_isModelLoaded(
        JNIEnv* /*env*/,
        jobject /*thiz*/) {
    std::lock_guard<std::mutex> lock(g_mutex);
    return (g_model != nullptr && g_ctx != nullptr) ? JNI_TRUE : JNI_FALSE;
}

// ------------------------------------------------------------------
// JNI: generate (streaming via callback)
// ------------------------------------------------------------------
extern "C"
JNIEXPORT jstring JNICALL
Java_com_omai_app_ai_chat_LlamaNative_generate(
        JNIEnv* env,
        jobject thiz,
        jstring prompt_j,
        jint max_tokens,
        jfloat temperature,
        jfloat top_p,
        jint top_k,
        jfloat repeat_penalty,
        jint seed,
        jobject token_callback) {

    if (g_generating.exchange(true)) {
        return env->NewStringUTF("[error] generation already in progress");
    }
    g_cancel = false;

    std::string prompt = jstring_to_string(env, prompt_j);
    std::string full_output;

    // Resolve callback method once
    jclass callbackClass = env->GetObjectClass(token_callback);
    jmethodID onTokenMethod = env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;)V");
    if (!onTokenMethod) {
        LOGE("Callback method onToken(String) not found");
        g_generating = false;
        return env->NewStringUTF("[error] invalid callback");
    }

    {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (!g_model || !g_ctx) {
            g_generating = false;
            return env->NewStringUTF("[error] model not loaded");
        }

        // Clear previous KV cache
        llama_kv_cache_clear(g_ctx);

        // Tokenize
        const int n_prompt_tokens = -llama_tokenize(g_model, prompt.c_str(), prompt.size(),
                                                    nullptr, 0, true, true);
        if (n_prompt_tokens <= 0) {
            g_generating = false;
            return env->NewStringUTF("[error] tokenization failed");
        }

        std::vector<llama_token> tokens(n_prompt_tokens);
        if (llama_tokenize(g_model, prompt.c_str(), prompt.size(),
                           tokens.data(), tokens.size(), true, true) < 0) {
            g_generating = false;
            return env->NewStringUTF("[error] tokenize failed");
        }

        // Evaluate prompt
        for (size_t i = 0; i < tokens.size(); ++i) {
            if (g_cancel) break;
            llama_batch batch = llama_batch_get_one(&tokens[i], 1);
            if (llama_decode(g_ctx, batch) != 0) {
                LOGE("llama_decode failed on prompt");
                g_generating = false;
                return env->NewStringUTF("[error] decode failed");
            }
        }

        // Sampling parameters
        llama_sampler* smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
        if (temperature > 0.0f) {
            llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
        }
        if (top_k > 0) {
            llama_sampler_chain_add(smpl, llama_sampler_init_top_k(top_k));
        }
        if (top_p < 1.0f) {
            llama_sampler_chain_add(smpl, llama_sampler_init_top_p(top_p, 1));
        }
        llama_sampler_chain_add(smpl, llama_sampler_init_penalties(
                llama_n_vocab(g_model),
                llama_token_eos(g_model),
                llama_token_nl(g_model),
                repeat_penalty, 0.0f, 0.0f, false, false));
        if (seed >= 0) {
            llama_sampler_chain_add(smpl, llama_sampler_init_dist(seed));
        } else {
            llama_sampler_chain_add(smpl, llama_sampler_init_dist(time(nullptr)));
        }

        // Generation loop
        const int max_new = max_tokens > 0 ? max_tokens : 512;
        for (int i = 0; i < max_new; ++i) {
            if (g_cancel) {
                LOGI("Generation cancelled");
                break;
            }

            llama_token new_token = llama_sampler_sample(smpl, g_ctx, -1);
            llama_sampler_accept(smpl, new_token);

            if (llama_token_is_eog(g_model, new_token)) {
                break;
            }

            char buf[256];
            int n = llama_token_to_piece(g_model, new_token, buf, sizeof(buf), 0, true);
            if (n > 0) {
                std::string piece(buf, n);
                full_output += piece;

                // Stream to Java
                jstring jpiece = env->NewStringUTF(piece.c_str());
                env->CallVoidMethod(token_callback, onTokenMethod, jpiece);
                env->DeleteLocalRef(jpiece);

                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    LOGE("Exception in token callback");
                    break;
                }
            }

            // Decode the new token
            llama_batch batch = llama_batch_get_one(&new_token, 1);
            if (llama_decode(g_ctx, batch) != 0) {
                LOGE("llama_decode failed during generation");
                break;
            }
        }

        llama_sampler_free(smpl);
    }

    g_generating = false;
    return env->NewStringUTF(full_output.c_str());
}

// ------------------------------------------------------------------
// JNI: cancelGeneration
// ------------------------------------------------------------------
extern "C"
JNIEXPORT void JNICALL
Java_com_omai_app_ai_chat_LlamaNative_cancelGeneration(
        JNIEnv* /*env*/,
        jobject /*thiz*/) {
    g_cancel = true;
    LOGI("Cancel requested");
}

// ------------------------------------------------------------------
// JNI: getModelInfo
// ------------------------------------------------------------------
extern "C"
JNIEXPORT jstring JNICALL
Java_com_omai_app_ai_chat_LlamaNative_getModelInfo(
        JNIEnv* env,
        jobject /*thiz*/) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model) {
        return env->NewStringUTF("No model loaded");
    }
    char buf[512];
    snprintf(buf, sizeof(buf),
             "n_vocab=%d n_ctx_train=%d n_embd=%d",
             llama_n_vocab(g_model),
             llama_n_ctx_train(g_model),
             llama_n_embd(g_model));
    return env->NewStringUTF(buf);
}
