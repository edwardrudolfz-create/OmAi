# Place llama.cpp source here
git clone --depth 1 https://github.com/ggerganov/llama.cpp.git .
