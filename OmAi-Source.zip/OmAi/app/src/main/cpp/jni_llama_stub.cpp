#include <jni.h>
#include <android/log.h>

#define LOG_TAG "OmAiLlamaStub"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jboolean JNICALL
Java_com_omai_app_ai_chat_LlamaNative_loadModel(JNIEnv*, jobject, jstring, jint, jint) {
    LOGE("Stub: llama.cpp sources were not available at build time");
    return JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_omai_app_ai_chat_LlamaNative_unloadModel(JNIEnv*, jobject) {}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_omai_app_ai_chat_LlamaNative_isModelLoaded(JNIEnv*, jobject) { return JNI_FALSE; }
extern "C" JNIEXPORT jstring JNICALL
Java_com_omai_app_ai_chat_LlamaNative_generate(JNIEnv* env, jobject, jstring, jint, jfloat, jfloat, jint, jfloat, jint, jobject) {
    return env->NewStringUTF("[error] native library is a stub – rebuild with llama.cpp sources");
}
extern "C" JNIEXPORT void JNICALL
Java_com_omai_app_ai_chat_LlamaNative_cancelGeneration(JNIEnv*, jobject) {}
extern "C" JNIEXPORT jstring JNICALL
Java_com_omai_app_ai_chat_LlamaNative_getModelInfo(JNIEnv* env, jobject) {
    return env->NewStringUTF("stub");
}
