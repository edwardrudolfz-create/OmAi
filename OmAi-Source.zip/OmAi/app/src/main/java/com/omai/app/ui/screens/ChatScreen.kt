package com.omai.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.omai.app.OmAiApplication
import com.omai.app.ai.ChatGenerationParams
import com.omai.app.data.model.MessageEntity
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(app: OmAiApplication) {
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var isGenerating by remember { mutableStateOf(false) }
    var streamingText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var chatId by remember { mutableStateOf<Long?>(null) }
    val messages = remember { mutableStateListOf<MessageEntity>() }
    val listState = rememberLazyListState()

    // Simple single-chat for V1 (can be expanded to multi-chat later)
    LaunchedEffect(Unit) {
        if (chatId == null) {
            chatId = app.chatRepository.createChat("OmAi Chat")
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("OmAi Chat (Local)") })

        if (!app.chatBackend.isModelLoaded()) {
            Card(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Text(
                    "No chat model loaded.\nGo to Models → Import a .gguf file (e.g. TinyLlama-1.1B-Q4_K_M.gguf).",
                    Modifier.padding(16.dp)
                )
            }
        }

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.role == "user"
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUser) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Text(msg.content, Modifier.padding(12.dp))
                    }
                }
            }
            if (streamingText.isNotEmpty()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Text(streamingText, Modifier.padding(12.dp))
                    }
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message OmAi…") },
                enabled = !isGenerating
            )
            Spacer(Modifier.width(8.dp))
            if (isGenerating) {
                IconButton(onClick = {
                    app.chatBackend.cancel()
                    isGenerating = false
                }) {
                    Icon(Icons.Default.Stop, contentDescription = "Stop")
                }
            } else {
                IconButton(
                    onClick = {
                        if (input.isBlank() || !app.chatBackend.isModelLoaded()) return@IconButton
                        val userText = input.trim()
                        input = ""
                        scope.launch {
                            val cid = chatId ?: return@launch
                            app.chatRepository.addMessage(cid, "user", userText)
                            messages.add(MessageEntity(chatId = cid, role = "user", content = userText))
                            isGenerating = true
                            streamingText = ""
                            error = null
                            val params = ChatGenerationParams(
                                maxTokens = 512,
                                temperature = 0.7f,
                                topP = 0.9f,
                                topK = 40,
                                repeatPenalty = 1.1f
                            )
                            val prompt = buildString {
                                append("User: $userText\nAssistant:")
                            }
                            app.chatBackend.generateStreaming(prompt, params)
                                .catch { e ->
                                    error = e.message
                                    isGenerating = false
                                }
                                .collect { token ->
                                    streamingText += token
                                }
                            if (streamingText.isNotEmpty()) {
                                app.chatRepository.addMessage(cid, "assistant", streamingText)
                                messages.add(MessageEntity(chatId = cid, role = "assistant", content = streamingText))
                                streamingText = ""
                            }
                            isGenerating = false
                        }
                    },
                    enabled = app.chatBackend.isModelLoaded()
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send")
                }
            }
        }
    }
}
