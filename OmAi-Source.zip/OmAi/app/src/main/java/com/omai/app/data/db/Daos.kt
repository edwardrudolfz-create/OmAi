package com.omai.app.data.db

import androidx.room.*
import com.omai.app.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats ORDER BY updatedAt DESC")
    fun observeChats(): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chats WHERE id = :id")
    suspend fun getChat(id: Long): ChatEntity?

    @Insert
    suspend fun insertChat(chat: ChatEntity): Long

    @Update
    suspend fun updateChat(chat: ChatEntity)

    @Query("DELETE FROM chats WHERE id = :id")
    suspend fun deleteChat(id: Long)

    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY createdAt ASC")
    fun observeMessages(chatId: Long): Flow<List<MessageEntity>>

    @Insert
    suspend fun insertMessage(msg: MessageEntity): Long

    @Query("DELETE FROM messages WHERE chatId = :chatId")
    suspend fun clearMessages(chatId: Long)
}

@Dao
interface GenerationDao {
    @Query("SELECT * FROM generations ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<GenerationEntity>>

    @Query("SELECT * FROM generations WHERE isFavorite = 1 ORDER BY createdAt DESC")
    fun observeFavorites(): Flow<List<GenerationEntity>>

    @Query("SELECT * FROM generations WHERE isAdult = 1 ORDER BY createdAt DESC")
    fun observeAdult(): Flow<List<GenerationEntity>>

    @Insert
    suspend fun insert(gen: GenerationEntity): Long

    @Update
    suspend fun update(gen: GenerationEntity)

    @Query("DELETE FROM generations WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM generations WHERE id = :id")
    suspend fun getById(id: Long): GenerationEntity?
}

@Dao
interface CharacterDao {
    @Query("SELECT * FROM characters ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<CharacterEntity>>

    @Insert
    suspend fun insert(c: CharacterEntity): Long

    @Update
    suspend fun update(c: CharacterEntity)

    @Query("DELETE FROM characters WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM characters WHERE id = :id")
    suspend fun getById(id: Long): CharacterEntity?
}

@Dao
interface ModelDao {
    @Query("SELECT * FROM models ORDER BY addedAt DESC")
    fun observeAll(): Flow<List<ModelEntity>>

    @Query("SELECT * FROM models WHERE type = :type AND isEnabled = 1")
    fun observeByType(type: String): Flow<List<ModelEntity>>

    @Insert
    suspend fun insert(m: ModelEntity): Long

    @Update
    suspend fun update(m: ModelEntity)

    @Query("DELETE FROM models WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM models WHERE id = :id")
    suspend fun getById(id: Long): ModelEntity?
}
