package com.omai.app.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.omai.app.OmAiApplication
import com.omai.app.ai.ImageGenerationParams
import com.omai.app.data.model.CharacterEntity
import com.omai.app.data.model.GenerationEntity
import com.omai.app.data.model.ModelEntity
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun HomeScreen(app: OmAiApplication, nav: NavController) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("OmAi", style = MaterialTheme.typography.headlineLarge)
        Text("Private • Local-first • No credits", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(24.dp))
        Button(onClick = { nav.navigate("chat") }, Modifier.fillMaxWidth()) { Text("Chat") }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { nav.navigate("create") }, Modifier.fillMaxWidth()) { Text("Generate Image") }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { nav.navigate("img2img") }, Modifier.fillMaxWidth()) { Text("Image to Image") }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { nav.navigate("models") }, Modifier.fillMaxWidth()) { Text("Model Manager") }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { nav.navigate("gallery") }, Modifier.fillMaxWidth()) { Text("Gallery") }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { nav.navigate("characters") }, Modifier.fillMaxWidth()) { Text("Characters") }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { nav.navigate("settings") }, Modifier.fillMaxWidth()) { Text("Settings") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageToImageScreen(app: OmAiApplication) {
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var sourceBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var resultBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var isGenerating by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var denoise by remember { mutableStateOf(0.75f) }
    val adultMode = app.settingsRepository.adultModeEnabled

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        sourceUri = uri
        uri?.let {
            app.contentResolver.openInputStream(it)?.use { stream ->
                sourceBitmap = BitmapFactory.decodeStream(stream)
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        TopAppBar(title = { Text("Image to Image") })
        Button(onClick = { picker.launch("image/*") }) { Text("Pick source image") }
        sourceBitmap?.let {
            Spacer(Modifier.height(8.dp))
            Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().height(200.dp), contentScale = ContentScale.Fit)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("Prompt") }, Modifier.fillMaxWidth())
        Text("Denoise: ${"%.2f".format(denoise)}")
        Slider(value = denoise, onValueChange = { denoise = it }, valueRange = 0.1f..1f)
        Button(
            onClick = {
                val src = sourceBitmap ?: return@Button
                if (!app.imageBackend.isModelLoaded()) return@Button
                scope.launch {
                    isGenerating = true
                    error = null
                    val params = ImageGenerationParams(prompt = prompt, denoiseStrength = denoise)
                    app.imageBackend.imageToImage(src, params)
                        .onSuccess { gen ->
                            resultBitmap = gen.bitmap
                            app.generationRepository.saveGeneration(
                                gen.bitmap, "img2img", prompt, "", gen.seed,
                                gen.width, gen.height, 20, 7f,
                                app.imageBackend.getLoadedModelPath() ?: "", null, adultMode
                            )
                        }
                        .onFailure { error = it.message }
                    isGenerating = false
                }
            },
            enabled = sourceBitmap != null && app.imageBackend.isModelLoaded() && !isGenerating,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (isGenerating) "Working…" else "Generate") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        resultBitmap?.let {
            Spacer(Modifier.height(12.dp))
            Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().height(300.dp), contentScale = ContentScale.Fit)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelManagerScreen(app: OmAiApplication) {
    val scope = rememberCoroutineScope()
    val models by app.modelRepository.observeAll().collectAsState(initial = emptyList())
    var status by remember { mutableStateOf("") }

    val chatPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            status = "Importing…"
            app.modelRepository.importModel(uri, "chat")
                .onSuccess {
                    status = "Imported chat model: ${it.name}"
                    // Auto-load
                    app.chatBackend.loadModel(it.filePath)
                        .onSuccess { status = "Chat model loaded" }
                        .onFailure { e -> status = "Imported but load failed: ${e.message}" }
                }
                .onFailure { status = "Import failed: ${it.message}" }
        }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            status = "Importing…"
            app.modelRepository.importModel(uri, "image")
                .onSuccess {
                    status = "Imported image model: ${it.name}"
                    app.imageBackend.loadModel(it.filePath)
                        .onSuccess { status = "Image model loaded" }
                        .onFailure { e -> status = "Imported but load failed: ${e.message}" }
                }
                .onFailure { status = "Import failed: ${it.message}" }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TopAppBar(title = { Text("Model Manager") })
        Text(status, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { chatPicker.launch(arrayOf("*/*")) }) { Text("Import GGUF (Chat)") }
            Button(onClick = { imagePicker.launch(arrayOf("*/*")) }) { Text("Import ONNX (Image)") }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(models) { m ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(m.name, style = MaterialTheme.typography.titleMedium)
                        Text("${m.type} • ${m.format} • ${m.fileSizeBytes / 1024 / 1024} MB")
                        Text(m.filePath, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        Row {
                            TextButton(onClick = {
                                scope.launch {
                                    if (m.type == "chat") {
                                        app.chatBackend.loadModel(m.filePath)
                                            .onSuccess { status = "Loaded chat: ${m.name}" }
                                            .onFailure { status = it.message ?: "Load failed" }
                                    } else {
                                        app.imageBackend.loadModel(m.filePath)
                                            .onSuccess { status = "Loaded image: ${m.name}" }
                                            .onFailure { status = it.message ?: "Load failed" }
                                    }
                                }
                            }) { Text("Load") }
                            TextButton(onClick = {
                                scope.launch {
                                    app.modelRepository.deleteModel(m)
                                    status = "Deleted ${m.name}"
                                }
                            }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GalleryScreen(app: OmAiApplication) {
    val gens by app.generationRepository.observeAll().collectAsState(initial = emptyList())
    LazyVerticalGrid(columns = GridCells.Adaptive(140.dp), contentPadding = PaddingValues(8.dp)) {
        items(gens) { g ->
            val bmp = remember(g.localPath) {
                try { BitmapFactory.decodeFile(g.localPath) } catch (_: Exception) { null }
            }
            Card(Modifier.padding(4.dp)) {
                Column {
                    bmp?.let {
                        Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().height(140.dp), contentScale = ContentScale.Crop)
                    }
                    Text(g.prompt, maxLines = 2, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(4.dp))
                }
            }
        }
    }
}

@Composable
fun CharactersScreen(app: OmAiApplication) {
    val chars by app.characterRepository.observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Characters", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, Modifier.fillMaxWidth())
        OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") }, Modifier.fillMaxWidth())
        OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("Default prompt") }, Modifier.fillMaxWidth())
        Button(onClick = {
            if (name.isBlank()) return@Button
            scope.launch {
                app.characterRepository.insert(
                    CharacterEntity(name = name, description = desc, defaultPrompt = prompt)
                )
                name = ""; desc = ""; prompt = ""
            }
        }) { Text("Add Character") }
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            items(chars) { c ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(c.name, style = MaterialTheme.typography.titleMedium)
                        Text(c.description)
                        Text(c.defaultPrompt, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(app: OmAiApplication) {
    var adult by remember { mutableStateOf(app.settingsRepository.adultModeEnabled) }
    var ageConfirmed by remember { mutableStateOf(app.settingsRepository.adultModeAgeConfirmed) }
    var showAgeDialog by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Adult Mode (fictional adults only)", Modifier.weight(1f))
            Switch(
                checked = adult,
                onCheckedChange = {
                    if (it && !ageConfirmed) {
                        showAgeDialog = true
                    } else {
                        adult = it
                        app.settingsRepository.adultModeEnabled = it
                    }
                }
            )
        }
        Text(
            "When enabled, the app allows maximum creative freedom for legal fictional adult characters. " +
                    "Permanent blocks remain for minors and non-consensual real-person content.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(24.dp))
        Text("Inference is 100% local. No cloud, no credits, no accounts.", style = MaterialTheme.typography.bodyMedium)
        Text("Chat: llama.cpp + GGUF", style = MaterialTheme.typography.bodySmall)
        Text("Image: ONNX Runtime Mobile", style = MaterialTheme.typography.bodySmall)
    }

    if (showAgeDialog) {
        AlertDialog(
            onDismissRequest = { showAgeDialog = false },
            title = { Text("Age Confirmation") },
            text = {
                Text("Adult Mode is for users 18+. It enables creative freedom for fictional adult characters only. " +
                        "Sexual content involving minors or non-consensual real-person deepfakes remains permanently blocked.")
            },
            confirmButton = {
                TextButton(onClick = {
                    ageConfirmed = true
                    app.settingsRepository.adultModeAgeConfirmed = true
                    adult = true
                    app.settingsRepository.adultModeEnabled = true
                    showAgeDialog = false
                }) { Text("I am 18+") }
            },
            dismissButton = {
                TextButton(onClick = { showAgeDialog = false }) { Text("Cancel") }
            }
        )
    }
}
