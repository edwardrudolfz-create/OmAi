package com.omai.app.data.repository

import android.content.Context
import android.graphics.Bitmap
import com.omai.app.data.db.CharacterDao
import com.omai.app.data.db.ChatDao
import com.omai.app.data.db.GenerationDao
import com.omai.app.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class ChatRepository(private val dao: ChatDao) {
    fun observeChats() = dao.observeChats()
    fun observeMessages(chatId: Long) = dao.observeMessages(chatId)
    suspend fun createChat(title: String, systemPrompt: String = ""): Long =
        dao.insertChat(ChatEntity(title = title, systemPrompt = systemPrompt))
    suspend fun addMessage(chatId: Long, role: String, content: String): Long =
        dao.insertMessage(MessageEntity(chatId = chatId, role = role, content = content))
    suspend fun deleteChat(id: Long) {
        dao.clearMessages(id)
        dao.deleteChat(id)
    }
    suspend fun renameChat(id: Long, title: String) {
        dao.getChat(id)?.let { dao.updateChat(it.copy(title = title, updatedAt = System.currentTimeMillis())) }
    }
}

class GenerationRepository(
    private val context: Context,
    private val dao: GenerationDao
) {
    private val imagesDir by lazy {
        File(context.filesDir, "generations").also { if (!it.exists()) it.mkdirs() }
    }

    fun observeAll() = dao.observeAll()
    fun observeFavorites() = dao.observeFavorites()
    fun observeAdult() = dao.observeAdult()

    suspend fun saveGeneration(
        bitmap: Bitmap,
        type: String,
        prompt: String,
        negativePrompt: String,
        seed: Int,
        width: Int,
        height: Int,
        steps: Int,
        cfgScale: Float,
        modelPath: String,
        characterId: Long?,
        isAdult: Boolean
    ): Long = withContext(Dispatchers.IO) {
        val file = File(imagesDir, "gen_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        dao.insert(
            GenerationEntity(
                type = type,
                prompt = prompt,
                negativePrompt = negativePrompt,
                seed = seed,
                width = width,
                height = height,
                steps = steps,
                cfgScale = cfgScale,
                modelPath = modelPath,
                characterId = characterId,
                localPath = file.absolutePath,
                isAdult = isAdult
            )
        )
    }

    suspend fun toggleFavorite(id: Long) {
        dao.getById(id)?.let { dao.update(it.copy(isFavorite = !it.isFavorite)) }
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) {
        dao.getById(id)?.let {
            File(it.localPath).delete()
            dao.delete(id)
        }
    }
}

class CharacterRepository(
    private val context: Context,
    private val dao: CharacterDao
) {
    private val refsDir by lazy {
        File(context.filesDir, "character_refs").also { if (!it.exists()) it.mkdirs() }
    }

    fun observeAll() = dao.observeAll()
    suspend fun getById(id: Long) = dao.getById(id)
    suspend fun insert(c: CharacterEntity) = dao.insert(c)
    suspend fun update(c: CharacterEntity) = dao.update(c)
    suspend fun delete(id: Long) = dao.delete(id)

    fun getRefsDir() = refsDir
}

class SettingsRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("omai_settings", Context.MODE_PRIVATE)

    var adultModeEnabled: Boolean
        get() = prefs.getBoolean("adult_mode", false)
        set(v) = prefs.edit().putBoolean("adult_mode", v).apply()

    var adultModeAgeConfirmed: Boolean
        get() = prefs.getBoolean("adult_age_confirmed", false)
        set(v) = prefs.edit().putBoolean("adult_age_confirmed", v).apply()

    var themeMode: String
        get() = prefs.getString("theme", "system") ?: "system"
        set(v) = prefs.edit().putString("theme", v).apply()

    var lastChatModelPath: String?
        get() = prefs.getString("last_chat_model", null)
        set(v) = prefs.edit().putString("last_chat_model", v).apply()

    var lastImageModelPath: String?
        get() = prefs.getString("last_image_model", null)
        set(v) = prefs.edit().putString("last_image_model", v).apply()
}
