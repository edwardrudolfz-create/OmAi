package com.omai.app.ai.chat

/**
 * JNI bridge to the native llama.cpp library (libomai_llama.so).
 *
 * This class is the only place that talks to native code.
 * All higher-level logic lives in LlamaChatBackend.
 */
object LlamaNative {

    init {
        try {
            System.loadLibrary("omai_llama")
        } catch (e: UnsatisfiedLinkError) {
            // Native library not built yet – developer must build with NDK.
            // The rest of the app will show a clear error when trying to load a model.
            android.util.Log.e("LlamaNative", "Failed to load libomai_llama.so", e)
        }
    }

    /**
     * Load a GGUF model from an absolute filesystem path.
     * @param modelPath absolute path to .gguf file
     * @param nCtx context length (e.g. 2048, 4096)
     * @param nThreads number of CPU threads (recommend Runtime.getRuntime().availableProcessors() - 1)
     * @return true if model + context created successfully
     */
    external fun loadModel(modelPath: String, nCtx: Int, nThreads: Int): Boolean

    /** Unload model and free all native memory. */
    external fun unloadModel()

    /** Whether a model is currently loaded. */
    external fun isModelLoaded(): Boolean

    /**
     * Generate text with streaming.
     * The callback receives each new token piece as soon as it is produced.
     * Returns the full generated string when finished (or empty on error).
     */
    external fun generate(
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        topK: Int,
        repeatPenalty: Float,
        seed: Int,
        tokenCallback: TokenCallback
    ): String

    /** Request cancellation of the current generation. */
    external fun cancelGeneration()

    /** Simple model info string for debugging. */
    external fun getModelInfo(): String

    /**
     * Java side of the streaming callback.
     * Implemented by LlamaChatBackend.
     */
    interface TokenCallback {
        fun onToken(token: String)
    }
}
