package com.omai.app.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.omai.app.OmAiApplication
import com.omai.app.ai.ImageGenerationParams
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextToImageScreen(app: OmAiApplication) {
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var negative by remember { mutableStateOf("") }
    var seed by remember { mutableStateOf(-1) }
    var steps by remember { mutableStateOf(20) }
    var width by remember { mutableStateOf(512) }
    var height by remember { mutableStateOf(512) }
    var isGenerating by remember { mutableStateOf(false) }
    var resultBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val adultMode = app.settingsRepository.adultModeEnabled

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        TopAppBar(title = { Text("Text to Image (Local)") })

        if (!app.imageBackend.isModelLoaded()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "No image model loaded.\nGo to Models → Import a compatible .onnx model.",
                    Modifier.padding(16.dp)
                )
            }
            Spacer(Modifier.height(12.dp))
        }

        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = { Text("Prompt") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = negative,
            onValueChange = { negative = it },
            label = { Text("Negative prompt") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = seed.toString(),
                onValueChange = { seed = it.toIntOrNull() ?: -1 },
                label = { Text("Seed (-1=random)") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = steps.toString(),
                onValueChange = { steps = it.toIntOrNull() ?: 20 },
                label = { Text("Steps") },
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = width.toString(),
                onValueChange = { width = it.toIntOrNull() ?: 512 },
                label = { Text("Width") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = height.toString(),
                onValueChange = { height = it.toIntOrNull() ?: 512 },
                label = { Text("Height") },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (prompt.isBlank() || !app.imageBackend.isModelLoaded()) return@Button
                scope.launch {
                    isGenerating = true
                    error = null
                    resultBitmap = null
                    val params = ImageGenerationParams(
                        prompt = prompt,
                        negativePrompt = negative,
                        width = width,
                        height = height,
                        steps = steps,
                        seed = seed
                    )
                    val result = app.imageBackend.textToImage(params)
                    result.onSuccess { gen ->
                        resultBitmap = gen.bitmap
                        app.generationRepository.saveGeneration(
                            bitmap = gen.bitmap,
                            type = "txt2img",
                            prompt = prompt,
                            negativePrompt = negative,
                            seed = gen.seed,
                            width = gen.width,
                            height = gen.height,
                            steps = steps,
                            cfgScale = 7f,
                            modelPath = app.imageBackend.getLoadedModelPath() ?: "",
                            characterId = null,
                            isAdult = adultMode
                        )
                    }.onFailure {
                        error = it.message
                    }
                    isGenerating = false
                }
            },
            enabled = !isGenerating && app.imageBackend.isModelLoaded(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isGenerating) "Generating…" else "Generate")
        }

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        }

        resultBitmap?.let { bmp ->
            Spacer(Modifier.height(16.dp))
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "Generated",
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 512.dp)
            )
        }
    }
}
