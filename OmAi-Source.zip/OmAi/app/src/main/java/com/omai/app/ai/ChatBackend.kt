package com.omai.app.ai

import kotlinx.coroutines.flow.Flow

/**
 * Abstraction for local chat inference.
 * Current implementation: LlamaChatBackend (llama.cpp + GGUF).
 */
interface ChatBackend {
    suspend fun loadModel(modelPath: String, nCtx: Int = 2048, nThreads: Int = 0): Result<Unit>
    suspend fun unloadModel()
    fun isModelLoaded(): Boolean
    fun generateStreaming(prompt: String, params: ChatGenerationParams): Flow<String>
    fun cancel()
    fun getLoadedModelPath(): String?
}

data class ChatGenerationParams(
    val maxTokens: Int = 512,
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val repeatPenalty: Float = 1.1f,
    val seed: Int = -1 // -1 = random
)

data class ChatResult(
    val text: String,
    val tokensGenerated: Int = 0,
    val timeMs: Long = 0
)
