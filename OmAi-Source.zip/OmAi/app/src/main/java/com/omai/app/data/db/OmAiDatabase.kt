package com.omai.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.omai.app.data.model.*

@Database(
    entities = [
        ChatEntity::class,
        MessageEntity::class,
        GenerationEntity::class,
        CharacterEntity::class,
        ModelEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class OmAiDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun generationDao(): GenerationDao
    abstract fun characterDao(): CharacterDao
    abstract fun modelDao(): ModelDao

    companion object {
        @Volatile private var INSTANCE: OmAiDatabase? = null

        fun getInstance(context: Context): OmAiDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    OmAiDatabase::class.java,
                    "omai.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}
