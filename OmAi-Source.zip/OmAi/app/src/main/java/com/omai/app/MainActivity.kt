package com.omai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import com.omai.app.ui.OmAiNavHost
import com.omai.app.ui.theme.OmAiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as OmAiApplication
        setContent {
            val settings = remember { app.settingsRepository }
            val themeMode = settings.themeMode
            val dark = when (themeMode) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }
            OmAiTheme(darkTheme = dark) {
                OmAiNavHost(app = app)
            }
        }
    }
}
