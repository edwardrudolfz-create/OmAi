package com.omai.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val systemPrompt: String = ""
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatId: Long,
    val role: String, // "user" | "assistant" | "system"
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "generations")
data class GenerationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // "txt2img" | "img2img"
    val prompt: String,
    val negativePrompt: String = "",
    val seed: Int = -1,
    val width: Int = 512,
    val height: Int = 512,
    val steps: Int = 20,
    val cfgScale: Float = 7f,
    val modelPath: String = "",
    val characterId: Long? = null,
    val localPath: String, // absolute path to saved image
    val createdAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val isAdult: Boolean = false
)

@Entity(tableName = "characters")
data class CharacterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String = "",
    val defaultPrompt: String = "",
    val negativePrompt: String = "",
    val referenceImagePaths: String = "", // comma-separated absolute paths
    val selectedModelPath: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "models")
data class ModelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String, // "chat" | "image" | "upscaler" | "lora"
    val filePath: String,
    val fileSizeBytes: Long = 0,
    val format: String, // "gguf" | "onnx" | "safetensors"
    val isEnabled: Boolean = true,
    val addedAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)

class Converters {
    @TypeConverter
    fun fromStringList(value: String): List<String> =
        if (value.isBlank()) emptyList() else value.split(",").map { it.trim() }

    @TypeConverter
    fun toStringList(list: List<String>): String = list.joinToString(",")
}
