package com.omai.app.ai

import android.graphics.Bitmap

interface ImageBackend {
    suspend fun loadModel(modelPath: String): Result<Unit>
    suspend fun unloadModel()
    fun isModelLoaded(): Boolean
    suspend fun textToImage(params: ImageGenerationParams): Result<ImageGenerationResult>
    suspend fun imageToImage(source: Bitmap, params: ImageGenerationParams): Result<ImageGenerationResult>
    fun cancel()
    fun getLoadedModelPath(): String?
}

data class ImageGenerationParams(
    val prompt: String = "",
    val negativePrompt: String = "",
    val width: Int = 512,
    val height: Int = 512,
    val steps: Int = 20,
    val cfgScale: Float = 7.0f,
    val seed: Int = -1,
    val denoiseStrength: Float = 0.75f, // for img2img
    val numImages: Int = 1
)

data class ImageGenerationResult(
    val bitmap: Bitmap,
    val seed: Int,
    val width: Int,
    val height: Int
)
