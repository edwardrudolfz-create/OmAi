package com.omai.app

import android.app.Application
import com.omai.app.ai.chat.LlamaChatBackend
import com.omai.app.ai.image.OnnxImageBackend
import com.omai.app.data.db.OmAiDatabase
import com.omai.app.data.repository.CharacterRepository
import com.omai.app.data.repository.ChatRepository
import com.omai.app.data.repository.GenerationRepository
import com.omai.app.data.repository.ModelRepository
import com.omai.app.data.repository.SettingsRepository

class OmAiApplication : Application() {

    lateinit var database: OmAiDatabase
        private set

    lateinit var chatBackend: LlamaChatBackend
        private set

    lateinit var imageBackend: OnnxImageBackend
        private set

    lateinit var modelRepository: ModelRepository
        private set

    lateinit var chatRepository: ChatRepository
        private set

    lateinit var generationRepository: GenerationRepository
        private set

    lateinit var characterRepository: CharacterRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = OmAiDatabase.getInstance(this)
        chatBackend = LlamaChatBackend()
        imageBackend = OnnxImageBackend(this)
        modelRepository = ModelRepository(this, database.modelDao())
        chatRepository = ChatRepository(database.chatDao())
        generationRepository = GenerationRepository(this, database.generationDao())
        characterRepository = CharacterRepository(this, database.characterDao())
        settingsRepository = SettingsRepository(this)
    }
}
