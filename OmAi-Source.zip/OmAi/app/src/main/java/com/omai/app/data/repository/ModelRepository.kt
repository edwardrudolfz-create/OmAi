package com.omai.app.data.repository

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.omai.app.data.db.ModelDao
import com.omai.app.data.model.ModelEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Handles import of local model files via Storage Access Framework.
 * Copies the selected file into the app's private models directory
 * and registers it in the Room database.
 */
class ModelRepository(
    private val context: Context,
    private val dao: ModelDao
) {
    private val modelsDir: File by lazy {
        File(context.filesDir, "models").also { if (!it.exists()) it.mkdirs() }
    }

    fun observeAll(): Flow<List<ModelEntity>> = dao.observeAll()
    fun observeByType(type: String): Flow<List<ModelEntity>> = dao.observeByType(type)

    suspend fun importModel(uri: Uri, type: String, displayName: String? = null): Result<ModelEntity> =
        withContext(Dispatchers.IO) {
            try {
                val name = displayName ?: queryDisplayName(uri) ?: "model_${System.currentTimeMillis()}"
                val lower = name.lowercase()
                val format = when {
                    lower.endsWith(".gguf") -> "gguf"
                    lower.endsWith(".onnx") -> "onnx"
                    lower.endsWith(".safetensors") -> "safetensors"
                    else -> return@withContext Result.failure(
                        IllegalArgumentException("Unsupported format. Use .gguf (chat) or .onnx (image).")
                    )
                }

                // Type safety
                when (type) {
                    "chat" -> if (format != "gguf") return@withContext Result.failure(
                        IllegalArgumentException("Chat models must be .gguf")
                    )
                    "image" -> if (format != "onnx") return@withContext Result.failure(
                        IllegalArgumentException("Image models must be .onnx for the current backend")
                    )
                }

                val dest = File(modelsDir, "${System.currentTimeMillis()}_$name")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(dest).use { output ->
                        input.copyTo(output)
                    }
                } ?: return@withContext Result.failure(IllegalStateException("Cannot open selected file"))

                val entity = ModelEntity(
                    name = name,
                    type = type,
                    filePath = dest.absolutePath,
                    fileSizeBytes = dest.length(),
                    format = format
                )
                val id = dao.insert(entity)
                Result.success(entity.copy(id = id))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun deleteModel(model: ModelEntity) = withContext(Dispatchers.IO) {
        File(model.filePath).delete()
        dao.delete(model.id)
    }

    suspend fun setEnabled(model: ModelEntity, enabled: Boolean) {
        dao.update(model.copy(isEnabled = enabled))
    }

    private fun queryDisplayName(uri: Uri): String? {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) {
                return cursor.getString(idx)
            }
        }
        return null
    }

    fun getModelsDir(): File = modelsDir
}
