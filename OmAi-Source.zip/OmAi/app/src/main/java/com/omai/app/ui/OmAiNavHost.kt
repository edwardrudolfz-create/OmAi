package com.omai.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.omai.app.OmAiApplication
import com.omai.app.ui.screens.*

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    data object Home : Screen("home", "Home", Icons.Default.Home)
    data object Chat : Screen("chat", "Chat", Icons.Default.Chat)
    data object Create : Screen("create", "Create", Icons.Default.Image)
    data object Img2Img : Screen("img2img", "Img2Img", Icons.Default.AutoFixHigh)
    data object Characters : Screen("characters", "Chars", Icons.Default.Person)
    data object Gallery : Screen("gallery", "Gallery", Icons.Default.PhotoLibrary)
    data object Models : Screen("models", "Models", Icons.Default.Storage)
    data object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

@Composable
fun OmAiNavHost(app: OmAiApplication) {
    val navController = rememberNavController()
    val items = listOf(
        Screen.Home, Screen.Chat, Screen.Create,
        Screen.Gallery, Screen.Models, Screen.Settings
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val current = navBackStackEntry?.destination
                items.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) },
                        selected = current?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen(app, navController) }
            composable(Screen.Chat.route) { ChatScreen(app) }
            composable(Screen.Create.route) { TextToImageScreen(app) }
            composable(Screen.Img2Img.route) { ImageToImageScreen(app) }
            composable(Screen.Characters.route) { CharactersScreen(app) }
            composable(Screen.Gallery.route) { GalleryScreen(app) }
            composable(Screen.Models.route) { ModelManagerScreen(app) }
            composable(Screen.Settings.route) { SettingsScreen(app) }
        }
    }
}
