package com.omai.app.ai.chat

import android.util.Log
import com.omai.app.ai.ChatBackend
import com.omai.app.ai.ChatGenerationParams
import com.omai.app.ai.ChatResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.channels.awaitClose
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Real local chat backend powered by llama.cpp via JNI.
 *
 * Requirements:
 * - A .gguf model file must be imported via Model Manager and its absolute path
 *   passed to loadModel().
 * - Native library libomai_llama.so must be built with NDK (see CMakeLists.txt).
 *
 * This class does NOT return hardcoded answers. All text comes from the model.
 */
class LlamaChatBackend : ChatBackend {

    companion object {
        private const val TAG = "LlamaChatBackend"
    }

    private val isLoaded = AtomicBoolean(false)
    private var currentModelPath: String? = null

    override suspend fun loadModel(modelPath: String, nCtx: Int, nThreads: Int): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val file = File(modelPath)
                if (!file.exists() || !file.canRead()) {
                    return@withContext Result.failure(
                        IllegalArgumentException("Model file not found or not readable: $modelPath")
                    )
                }
                if (!modelPath.lowercase().endsWith(".gguf")) {
                    return@withContext Result.failure(
                        IllegalArgumentException("Only .gguf models are supported by this backend")
                    )
                }

                // Unload previous model if any
                if (isLoaded.get()) {
                    LlamaNative.unloadModel()
                    isLoaded.set(false)
                }

                val threads = if (nThreads > 0) nThreads
                else (Runtime.getRuntime().availableProcessors() - 1).coerceAtLeast(1)

                val ok = LlamaNative.loadModel(modelPath, nCtx.coerceIn(512, 8192), threads)
                if (ok) {
                    isLoaded.set(true)
                    currentModelPath = modelPath
                    Log.i(TAG, "Model loaded: $modelPath  info=${LlamaNative.getModelInfo()}")
                    Result.success(Unit)
                } else {
                    Result.failure(RuntimeException("Native loadModel returned false. Check logcat for llama.cpp errors."))
                }
            } catch (e: UnsatisfiedLinkError) {
                Result.failure(
                    RuntimeException(
                        "Native library not loaded. Build the project with NDK so that libomai_llama.so is packaged.",
                        e
                    )
                )
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    override suspend fun unloadModel() = withContext(Dispatchers.IO) {
        if (isLoaded.get()) {
            LlamaNative.unloadModel()
            isLoaded.set(false)
            currentModelPath = null
        }
    }

    override fun isModelLoaded(): Boolean = isLoaded.get() && LlamaNative.isModelLoaded()

    override fun generateStreaming(
        prompt: String,
        params: ChatGenerationParams
    ): Flow<String> = callbackFlow {
        if (!isModelLoaded()) {
            close(IllegalStateException("No model loaded. Import a GGUF model in Model Manager first."))
            return@callbackFlow
        }

        val callback = object : LlamaNative.TokenCallback {
            override fun onToken(token: String) {
                trySend(token)
            }
        }

        // Run the blocking native call on IO dispatcher
        val job = kotlinx.coroutines.launch(Dispatchers.IO) {
            try {
                val full = LlamaNative.generate(
                    prompt = prompt,
                    maxTokens = params.maxTokens,
                    temperature = params.temperature,
                    topP = params.topP,
                    topK = params.topK,
                    repeatPenalty = params.repeatPenalty,
                    seed = params.seed,
                    tokenCallback = callback
                )
                if (full.startsWith("[error]")) {
                    close(RuntimeException(full))
                } else {
                    close()
                }
            } catch (e: Exception) {
                close(e)
            }
        }

        awaitClose {
            LlamaNative.cancelGeneration()
            job.cancel()
        }
    }

    override fun cancel() {
        LlamaNative.cancelGeneration()
    }

    override fun getLoadedModelPath(): String? = currentModelPath
}
