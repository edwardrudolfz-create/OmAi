# OmAi v1.0 – Local-First Android AI

**Private • No cloud inference • No credits • No subscriptions**

OmAi runs AI **on your phone**. Chat uses llama.cpp (GGUF). Image generation uses ONNX Runtime Mobile.

---

## 📱 Phone-Only: Build the APK with GitHub Actions (No PC needed)

You only need a phone + a free GitHub account.

### Step 1 – Create a GitHub repository (mobile browser)

1. Open https://github.com in your phone browser and sign in (or create a free account).
2. Tap the **+** button → **New repository**.
3. Name it `OmAi` (or any name).
4. Leave it **Public** (required for free Actions minutes on private repos is limited).
5. Tap **Create repository**.

### Step 2 – Upload the OmAi project

**Easiest way on phone:**

1. Download `OmAi-Source.zip` to your phone.
2. On the new empty repository page, tap **uploading an existing file**.
3. Select **all files and folders** from inside the unzipped `OmAi` folder  
   (or upload the whole zip and then extract on GitHub is not possible – better to use a file manager that can upload folders, or use the GitHub mobile app / a simple Git client).

**Practical mobile method:**

- Use the free app **MGit** or **GitHub** official app, or
- Use a web-based Git client, or
- From a file manager that supports WebDAV / Git, push the unzipped content.

If the repository is empty you can also drag-and-drop the unzipped contents in desktop mode of the mobile browser.

**Important files that must be present:**

- `.github/workflows/build-apk.yml`
- `app/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `gradle/`
- `README.md`

### Step 3 – Run the build

1. On the repository page open the **Actions** tab.
2. You will see the workflow **“Build OmAi APK”**.
3. Tap it → **Run workflow** → **Run workflow** (green button).
4. Wait 10–25 minutes. The job will:
   - Install JDK 17
   - Install Android SDK 35 + NDK + CMake
   - Clone llama.cpp
   - Compile the native library
   - Build the APK

### Step 4 – Download the APK

1. When the workflow finishes with a green check, open the completed run.
2. Scroll to **Artifacts**.
3. Tap **OmAi-v1.0-debug** and download it.
4. The file is `OmAi-v1.0-debug.apk`.

### Step 5 – Install on your phone

1. Open the downloaded APK with your file manager.
2. Allow “Install from unknown sources” if asked.
3. Install.

---

## After installation

1. Open **OmAi**.
2. Go to **Models**.
3. Import a small **.gguf** chat model (see list below).
4. Import a compatible **.onnx** image model (optional for V1 image features).
5. Go to **Chat** and talk – answers come from the real local model.
6. All data stays on your phone. No cloud, no credits.

---

## Recommended small models for 8 GB phones

### Chat (GGUF) – download on phone from Hugging Face

| Model | Approx size | Notes |
|-------|-------------|-------|
| TinyLlama-1.1B-Chat-v1.0.Q4_K_M.gguf | ~0.7 GB | Fastest for testing |
| Phi-3-mini-4k-instruct-q4.gguf | ~2.3 GB | Better quality |
| Qwen2-1.5B-Instruct-Q4_K_M.gguf | ~1.0 GB | Multilingual |

Search on Hugging Face for “TheBloke” or official GGUF repos, download the `.gguf` file, then use **Models → Import GGUF** inside OmAi.

### Image (ONNX)

Any lightweight Stable-Diffusion / LCM / SD-Turbo ONNX export.  
The current backend expects common tensor names (`sample`, `timestep`, …).  
If your model uses different names, the first run will show a clear error in logcat; a future update can map them.

---

## What the GitHub Actions workflow does

File: `.github/workflows/build-apk.yml`

- Triggers on manual “Run workflow” or push to main/master
- Sets up **JDK 17** (Temurin)
- Installs **Android SDK 35**, **build-tools 35**, **NDK 26.1.10909125**, **CMake 3.22.1**
- Clones **llama.cpp** (tag b3600 or latest)
- Generates Gradle wrapper if needed
- Runs `./gradlew assembleDebug`
- Uploads **OmAi-v1.0-debug.apk** as a downloadable artifact
- Also uploads the build log so you can see errors on your phone

---

## Project structure (important parts)

```
OmAi/
├── .github/workflows/build-apk.yml   ← mobile CI build
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── cpp/                      ← JNI + CMake for llama.cpp
│       │   ├── CMakeLists.txt
│       │   ├── jni_llama.cpp
│       │   └── llama/                ← cloned by the workflow
│       └── java/com/omai/app/
│           ├── ai/chat/              ← real LlamaChatBackend
│           ├── ai/image/             ← real OnnxImageBackend
│           ├── data/                 ← Room DB
│           └── ui/                   ← Compose screens
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

---

## Adult Mode

- Off by default.
- Requires age confirmation (18+).
- When enabled: maximum creative freedom for **legal fictional adult** characters.
- Permanent hard blocks (cannot be turned off):
  - Sexual content involving minors / anyone under 18
  - Non-consensual explicit content of real identifiable people

---

## Troubleshooting the GitHub build

| Symptom | What to do |
|---------|------------|
| Workflow fails on “Clone llama.cpp” | Re-run the workflow. Network glitches happen. |
| Native compile error | Open the **build-log** artifact, search for “error:”. llama.cpp API sometimes changes; the JNI may need a small update. |
| “No APK was produced” | Check the build-log artifact. |
| APK installs but chat crashes | You need to import a real `.gguf` model via the Models screen. |
| Out of memory on phone | Use a smaller GGUF (Q4 or Q3, ≤ 2 GB). |

---

## Privacy

- No mandatory account
- No cloud AI
- No generation credits
- Chats, images, characters and models stay on your device only

**OmAi – your AI, on your hardware.**
